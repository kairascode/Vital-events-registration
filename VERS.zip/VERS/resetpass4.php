<?php include("header.php");?>
<html>
<head></head>
<body>

<?php
if(isset($_POST['submit']))
if (isset($_POST['user'])) { $username = $_POST['user']; }
if (isset($_POST['usercode'])) { $usercode = $_POST['usercode']; }
if (isset($_POST['opass'])) { $opass = $_POST['opass']; } 
if (isset($_POST['npass'])) { $npass = $_POST['npass']; } 
if (isset($_POST['cpass'])) { $cpass = $_POST['cpass']; } 

		 mysql_connect("localhost", "root", "") or die("We couldn't connect!");
            mysql_select_db("pomis");
			$qry=mysql_query("select*from staff where password='$opass'");
			$row=mysql_fetch_array($qry);
			$dbpass=$row['password'];
			if($opass==$dbpass){
			if($npass==$cpass){
			$update="UPDATE agents set password='$cpass' where username='$username' and staff_no='$usercode' and password='$opass'";
mysql_query($update,$conn);
			echo"<h3><font color='red'>$username, Your password has been reset</font></h3>";
			}
			else
			echo"Please enter new password again";
			}
			else
			echo"System does not recognize you";
			?>
			</body>
</html>