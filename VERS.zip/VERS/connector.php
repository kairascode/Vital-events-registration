<?php
$conn=mysql_connect("localhost","root","") or die("Server not found....!");
mysql_select_db("pomis") or die ("Couldn't find Database");
?>