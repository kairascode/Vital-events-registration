<html>
<head><title>DISTRICT DEATH STATISTICS</title><?php include("header.php");?></head>
<body>
<div><strong>
<form method="POST" action="approve.php">
TYPE
<select name="type" type="text">
<option value="birth">BIRTHS</option>
<option value="death">DEATH</option>
</select>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
AGENT CODE:<input type="text" name="agent" maxlength="4" required>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
MONTH:<input type="text" name="month" maxlength="4" required>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<input type="submit" name="submit" value="View" onclick="view"></strong>
</form>
</div >

</html>