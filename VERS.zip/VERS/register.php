<?if(isset($_POST['add']))
{
$dbhost='localhost';
$dbuser='root';
$conn=mysql_connect($dbhost,$dbuser);
if(!$conn)
{
die('could not connect'.mysql_error());
}
if(!get_magic_quotes_gpc() )
{
$username= addslashes ($_POST['username']);
$designation= addslashes ($_POST['designation']);
$remember= addslashes ($_POST['remember']);
}
else
{
$username=$_POST['username'];
$designation=$_POST['designation'];
$remember=$_POST['remember'];
}
mysql_select_db('pass');
$sql=mysql_query("insert into client(username,designation,remember) values('$username','$designation',$remember)");

$retval=mysql_query($sql,$conn);
if(!$retval)
{
die('entry unsuccessful,check your data...'.mysql_error());
}
echo "REGISTRATION successful, Thank you..\n";
mysql_close($conn);
}
else
{
?>
<?
}
?>


