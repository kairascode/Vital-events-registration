<HTML>
<head>
<?php 
session_start();
if(!$_SESSION['loggedin'])
{
header("location:login2.php");
exit;
}
else
echo"<p align='right'><h3><font color='orange'>Welcome, $username</h4></font></p>";
?>
</head>
<body>
<p align="right"><a href="registrar.php">Home</a>&nbsp&nbsp&nbsp <a href="logoff.php">Log out</a>
<?php
$db = mysql_connect("localhost","root", "");
mysql_select_db("pomis",$db);
//$agentno=mysql_query("select agentno from agents where Staff_no=(select staff_no from staff where username='$username')") ;
$result = mysql_query("SELECT * FROM breg where status='approved' AND agentno in(select usercode from agents where Staff_no in(select staff_no from staff where username='$username'))");
echo "<TABLE BORDER=2>";
echo"<TR bgcolor='orange'><TD><B>NO</B><TD><B>NOTIFICATION NO</B><TD><B>CHILD NAME</B><TD><B>DATE OF BIRTH</B><TD><B>PLACE OF BIRTH</B><TD><B>SEX</B><TD><B>MOTHER</B><TD><B>AGE</B>
<TD><B>ID CARD NO</B><TD><B>MARITAL STATUS</B><TD><B>RESIDENCE</B><TD><B>FATHER</B><TD><B>AGE</B><TD><B>ID CARD NO</B><TD><B>DATE REGISTERED</B>
<TD><B>INFORMANT</B><TD><B>AGENT NO</B><TD><B>COUNTY</B><TD><B>ACTION</B></TD><TD><B>TIME REGISTERED</B></TR>";
while ($myrow = mysql_fetch_array($result))
{
echo "<TR bgcolor='pink'><TD>".$myrow["no"]."<td>".$myrow["notification_no"]." <td>".$myrow["childname"]."<TD>".$myrow["dob"]."<TD>".$myrow["pob"]."<TD>".$myrow["sex"]."<TD>".$myrow["mother"].
"<TD>".$myrow["age"]."<td>".$myrow["id_no"]."<td>".$myrow["m_status"]."<td>".$myrow["residence"]."<TD>".$myrow["father"]."<td>".$myrow["age2"]."<td>".$myrow["id_no2"]."<TD>".$myrow["dreg"]."<TD>".$myrow["informant"]."<TD>".$myrow["agentno"]."<TD>".$myrow["county"]."<TD>".$myrow["status"]."<TD>".$myrow["timeSys"];
}
echo "</TABLE>";
?>
</body>
</HTML>
