<?php include("header.php");?>
<html>
<head><title>DISTRICT BIRTH STATISTICS</title>
<?php 
session_start();
if(!$_SESSION['loggedin'])
{
header("location:login2.php");
exit;
}
else
echo"<p align='right'><h3><font color='orange'>Welcome, $username</h4></font></p>";
?>`
</head>
<body>
<p align="right"><a href="registrar.php">Home</a>&nbsp&nbsp&nbsp <a href="logoff.php">Log out</a>
<hr>
<div id="birth">
<?php
$conn=mysql_connect("localhost","root","") or die("Server not found...");
mysql_select_db("pomis",$conn);
$sql=mysql_query("select*from breg where sex='FEMALE' and status='approved' AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$result=mysql_num_rows($sql);
$sql2=mysql_query("select*from breg where sex='MALE' and status='approved'AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$result2=mysql_num_rows($sql2);
$mumage1=mysql_query("select*from breg where age<20 and status='approved'AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultage1=mysql_num_rows($mumage1);
$mumage2=mysql_query("select*from breg where age>=20 and status='approved'AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultage2=mysql_num_rows($mumage2);
$singlemum=mysql_query("select*from breg where m_status='single' and status='approved'AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultsinglemum=mysql_num_rows($singlemum);
$withdad=mysql_query("select*from breg where m_status='married' and status='approved'AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultwithdad=mysql_num_rows($withdad);
$total=mysql_query("select*from breg where status='approved'AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultall=mysql_num_rows($total);
$Today = date('y:m:d');
$date=date('l, F d, Y',strtotime($Today));
echo"<table border=1 align='center'>";
echo"<th colspan=2 cellspacing=0 cellpadding=0>REGISTRY BIRTH STATISTICS AS AT $date</TH></TR>";
echo"<th>DESCRIPTION<th>No</tr>";
echo"<td><font color='blue'><h3>Total Birth events in the Registry</h3><td><b><p align='center'>$resultall</font></tr>";
echo"<td>Total Female birth events in the Registry<td width=100px><b><p align='center'>$result</tr>";
echo"<td>Total Male birth events in the Registry<td width=100px><b><p align='center'>$result2</tr>";
echo"<td>Total birth events where Mother is above teen in the Registry<td width=100px><b><p align='center'>$resultage2</p></tr>";
echo"<td>Total birth events where Mother is a teen in the Registry<td width=100px><b><p align='center'>$resultage1</tr>";
echo"<td>Total no of illegitimate births recorded in the Registry<td width=100px><b><p align='center'>$resultsinglemum</tr>";
echo"<td>Total no of legitimate births recorded in the Registry<td width=100px><b><p align='center'>$resultwithdad</tr>";
echo"<tr></tr>";
echo"</table>";
?>
</div><hr><br>
<div><background color="gray"></div>
<div id="death">
<?php
$conn=mysql_connect("localhost","root","") or die("Server not found...");
mysql_select_db("pomis",$conn);
$sqlf=mysql_query("select*from dreg where sex='FEMALE' and status='approved'AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultf=mysql_num_rows($sqlf);
$sqlm=mysql_query("select*from dreg where sex='MALE' and status='approved'AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultm=mysql_num_rows($sqlm);
$age1=mysql_query("select*from dreg where age<=35 and status='approved' AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultage1=mysql_num_rows($age1);
$age2=mysql_query("select*from dreg where age>35 and status='approved' AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultage2=mysql_num_rows($age2);
$pneumonia=mysql_query("select*from dreg where dcause='PNEUMONIA' and status='approved'AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultpneumonia=mysql_num_rows($pneumonia);
$aids=mysql_query("select*from dreg where dcause='AIDS' and status='approved'AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultaids=mysql_num_rows($aids);
$cancer=mysql_query("select*from dreg where dcause='cancer' and status='approved'AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultcancer=mysql_num_rows($cancer);
$accident=mysql_query("select*from dreg where dcause='Roadaccident' and status='approved'AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultaccident=mysql_num_rows($accident);
$totald=mysql_query("select*from dreg where status='approved'AND agentno in(select usercode from agents where Staff_no IN(select staff_no from staff where username='$username'))");
$resultalld=mysql_num_rows($totald);
$Today = date('y:m:d');
$date=date('l, F d, Y',strtotime($Today));


echo"<table border=1 align='center'>";
echo"<th colspan=2 cellspacing=0 cellpadding=0 background color=green>REGISTRY DEATH STATISTICS AS AT $date</TH></TR>";
echo"<th>DESCRIPTION<th>No</tr>";
echo"<td><font color='green'><h3>Total Death events in the Registry</h3><td><b><p align='center'>$resultalld</font></tr>";
echo"<td>Total Female death events in the Registry<td width=100px><b><p align='center'>$resultf</tr>";
echo"<td>Total Male death events in the Registry<td width=100px><b><p align='center'>$resultm</tr>";
echo"<td>Total youth death events in the Registry<td width=100px><b><p align='center'>$resultage1</tr>";
echo"<td>Total Pneumonia death events in the Registry<td width=100px><b><p align='center'>$resultpneumonia</tr>";
echo"<td>Total elderly death events in the Registry<td width=100px><b><p align='center'>$resultage2</tr>";
echo"<td>Total Road accident death events in the Registry<td width=100px><b><p align='center'>$resultaccident</tr>";
echo"<td>Total Cancer death events in the Registry<td width=100px><b><p align='center'>$resultcancer</tr>";
echo"<td>Total HIV/AIDS death events in the Registry<td width=100px><b><p align='center'>$resultaids</tr>";
//echo"<td>Total elderly death events in the Registry<td width=100px><b><p align='center'>$resultage2</tr>";
//echo"<td>Total Male death events =$resultm";
echo"</table>";
?></div><hr>

</body>

</html>
<?php include("footer.php")?>

