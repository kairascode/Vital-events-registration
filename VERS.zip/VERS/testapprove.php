<?
//$search=['agntno'];
$conn= mysql_connect("localhost","root","") or die("could not find server...");
mysql_select_db("pomis",$conn);
$sql=mysql_query("select*from dreg ");
while($row=mysql_fetch_array($sql))
{
echo"<table border=1>";
echo"<tr><th>AGENT NO<TH>PERMIT NO<TH>NAME<TH>SEX<TH>AGE<TH>ID CARD NO<TH>OCCUPATION<TH>DATE REGISTERED<TH>INFORMANT<TH>DESCRIPTION<th>APPROVE</TH></TR>";
echo"<tr><td>";echo $row['agentno'];echo"<td>";echo $row['permit_no'];echo"<td>";echo $row['dname'];echo"<td>";echo $row['sex']; echo"<td>";
echo $row['age'];echo "<td>"; echo $row['id_no'];echo "<td>";echo $row['occupation'];echo "<td>";echo $row['dreg'];echo "<td>";echo $row['informant'];
echo "<td>";echo$row['tinfo'];echo"<td>";echo"<a href='approve12.php?id=<?php echo $rec['agentno'];?>'><input type='button' value='Approve'/></a></td></tr>";
echo"</table>";


