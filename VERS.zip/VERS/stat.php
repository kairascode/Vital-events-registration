<html>
<head><title>STATISTICS</TITLE>
<?php include("header.php");?>
<?php 
session_start();
if(!$_SESSION['loggedin'])
{
header("location:login.php");
exit;
}
else
echo"<p align='right'><h3><font color='orange'>Welcome, $username</h4></font></p>";
?></head>
<body>
<div>
<ul>
<li><a href="stat1.php"onclick="view1">District Statistics</a><li><a href="registrar.php">Back to Profile</a><li><a href="logoff.php">Logout</a></LI></UL></div>
<div id="view1">
</div>
<div id="view2">
</div>


<?php include("footer.php");?>
