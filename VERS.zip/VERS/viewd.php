<HTML>
<head>
<?php 
session_start();
if(!$_SESSION['loggedin'])
{
header("location:login2.php");
exit;
}
else
echo"<p align='right'><h3><font color='orange'>Welcome, $username</h4></font></p>";
?>`
<p align="right"><a href="registrar.php">Home</a>&nbsp&nbsp&nbsp <a href="logoff.php">Log out</a>
</head>
<body>
<?php
$db = mysql_connect("localhost", "root", "");
mysql_select_db("pomis",$db);
$result = mysql_query("SELECT * FROM dreg where status='approved' AND agentno in(select usercode from agents where Staff_no in(select staff_no from staff where username='$username'))");
echo "<TABLE BORDER=2>";

echo"<TR><TD><B>NO</B><TD><B>PERMIT No</B><TD><B>DECEASED NAME</B><TD><B>DATE OF DEATH</B><TD><B>AGE</B><TD><B>ID CARD NO</B><TD><B>OCCUPATION</B><TD><B>SEX</B><TD><B>PLACE OF DEATH</B><TD><B>HOME COUNTY</B><TD><B>CAUSE OF DEATH</B><TD><B>INFORMANT</B>
<TD><B>DESCRIPTION</B><TD><B>DATE REGISTERED</B><TD><B>AGENT NO</B><TD><B>APPROVED</B></TD><TD><B>TIME REGISTERED</B></TR>";
while ($myrow = mysql_fetch_assoc($result))
{
echo "<TR><TD>".$myrow["no"]." <td>".$myrow["permit_no"]." <td>".$myrow["dname"]."<TD>".$myrow["dod"]."<TD>".$myrow["age"]."<TD>".$myrow["sex"]." <td>".$myrow["id_no"]." <td>".$myrow["occupation"]."<TD>".$myrow["pod"].
"<TD>".$myrow["county"]."<TD>".$myrow["dcause"]."<TD>".$myrow["informant"]."<TD>".$myrow["tinfo"]."<TD>".$myrow["dor"]."<td>".$myrow["agentno"]."<td>".$myrow["status"]."<TD>".$myrow["timeSys"];
//echo "<TR><TD>"$row["no"],$row["childname"],$row["dob"],$row["pob"],$row["sex"],$row["mother"],$row["age"],$row["father"],$row["dreg"],$row["informant"],$row["agentno"],$row["countyno"]"</td>""</tr>";
}
echo "</TABLE>";
mysql_close($db);

?>
</body>

</HTML>

