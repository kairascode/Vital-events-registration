<?include("header.php");?>
<html>
<link rel="stylesheet" type="text/css" a href="signup.css" media="screen">
<?if(isset($_POST['add']))
{
$dbhost='localhost';
$dbuser='root';
$conn=mysql_connect($dbhost,$dbuser);
if(!$conn)
{
die('could not connect'.mysql_error());
}
if(!get_magic_quotes_gpc() )
{
$username= addslashes ($_POST['username']);
$designation= addslashes ($_POST['designation']);
$remember= addslashes ($_POST['remember']);
}
else
{
$username=$_POST['username'];
$designation=$_POST['designation'];
}
mysql_select_db('pass');
$sql=mysql_query("insert into client(username,designation) values('$username','$designation')");

$retval=mysql_query($sql,$conn);
if(!$retval)
{
die('entry unsuccessful,check your data...'.mysql_error());
}
echo "REGISTRATION successful, Thank you..\n";
mysql_close($conn);
}
else
{
?>
<form method="post" action=="<? $_php_self?>">
<p align="right">POMIS<P align="center">SIGN UP PORTAL</p>
USER NAME:<input type="text" name="username" size="20"><br><br><hr>
DESIGNATION:<input type="text" name="designation" size="25"><br><br><hr>
PASSWORD:<input type="password" name="password" size="10"><br><br><hr>
<p align="right"><input type="submit" name="submit" value="SIGN UP"></p>
<p align="right"><input type="submit" name="submit" value="CANCEL"></p></form>
<?
}
?>
<?include("footer.php");?>