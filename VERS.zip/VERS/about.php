<?PHP include("header.php");?>
<html>
<p><font color="GREEN" size="8" style="calbri">VERS is a computer information system aimed at capturing Births and Deaths occurences at the Registration agents' level and
consequently, at the Registrar's level, enabling the printing of birth and death certificates,information storage as well as generating vital statistics(birth and death rates and the demographics)</font></p>
<?php include("footer.php");?>