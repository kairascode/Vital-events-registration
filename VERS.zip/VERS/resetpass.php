<html>
<head>
<link rel="stylesheet" type="text/css" a href="login.css">
<?php include("header.php");?>
</head>
<body>
<form method="POST" action="resetpass2.php">
<strong><p align="center"> RESET PASSWORD</P><br><hr>
 USER NAME:<input type="text" name="user" size="25" required><br><hr>
USER CODE:<input type="password" name="usercode" size="25" required><br><hr>
OLD PASSWORD:<input type="password" name="opass" size="20" required><br><hr>
NEW PASSWORD:<input type="password" name="npass" size="20" required><br><hr>
CONFIRM PASSWORD:<input type="password" name="cpass" size="20" required><br><hr>
<p align="right"><input type="submit" name="submit" value="RESET"></p></strong>
</form>
<?php include("footer.php");?>
</html>









