<html>
<head>
<?php include("header.php");?>
<?php 
session_start();
if(!$_SESSION['loggedin'])
{
header("location:login2.php");
exit;
}
else
echo"<p align='right'><h3><font color='orange'>Welcome Registrar $username</h4></font></p>";
?>
<table border="1" colspan="1">
<tr><td>
<?php
echo "$photo";
?>
<a href="staffmessage.php">Messages</a><hr>
<a href="tasks.php">Tasks</a><br>
<hr><a href="myagents.php">My Agents</a><br><hr>
<a href="approve.php">Approve Registers</a><br><hr>
<a href="#">View Registers</a><li><a href="viewb.php">Birth</a><li><a href="viewd.php">Death</a><br><hr>
<a href="cert.php">Process Certificates</a><br><hr>
<a href="stat1.php">Statistics</a><br><hr>
<a href="logoff.php">Log out</a><hr></td>
<td><img src="proxy.jpg" width=600 height=300></td>
<td width=200>Registration as per cap 149 Laws of Kenya</TD>
</tr></a></table>
</html>

<?php include("footer.php");?>