<?php include("header.php");?>
<html>
<head>
<?php 
session_start();
if(!$_SESSION['loggedin'])
{
header("location:login2.php");
exit;
}
else
echo"<p align='right'><h3><font color='orange'>Welcome,Registrar $username</h4></font></p>";
?>
</head>
<p align="right"><a href="registrar.php">Home</a>&nbsp&nbsp&nbsp <a href="logoff.php">Log out</a>
<body>
<div id="birth">
<?php
$conn=mysql_connect("localhost","root","")or die("COULD NOT CONNECT...");
mysql_select_db("pomis",$conn);
$qry=mysql_query(" SELECT agentno from breg where status!='approved' AND status!='rejected' AND agentno in(select usercode from agents where Staff_no in(select staff_no from staff where username='$username'))");
$result=mysql_fetch_array($qry);
$num_rows=mysql_num_rows($qry);
if($num_rows!=0){
$agent=$result;
echo"$num_rows birth events from ".$agent['agentno']." require your approval ";
}
else
echo" No registration of births has taken place since your last approval";
mysql_close($conn);
?>
</div>
<div id="death"> 
<?php
$conn=mysql_connect("localhost","root","")or die("COULD NOT CONNECT...");
mysql_select_db("pomis",$conn);
$qry1=mysql_query(" SELECT agentno from dreg where status!='approved' AND status!='rejected'");
$result=mysql_fetch_array($qry1);
$num_rows=mysql_num_rows($qry1);
if($num_rows!=0){
//while($row=mysql_fetch_array($qry){
//$agent==$row['agentno'];
$agent=$result;
$count=$num_rows;
echo"$count death events from ".$agent['agentno']." require your approval ";
}

else
echo"No registration of deaths has taken place since your last approval";
mysql_close($conn);

?>
</div>
</body>
</html>