
<html>
<head>
<title>VERS</TITLE>
<link rel="stylesheet" type="text/css" a href="pmis.css" media="all">
<link rel="stylesheet" type="text/css" a href="style.css" media="all">


</head>
<body>


<div id="mwili">
<p align="center"><h1>VITAL EVENTS REGISTRATION SYSTEM - VERS <BR><I>Getting everyone in the picture</i></h1></p><hr>
<div id="ingia">
<p align="right" font color="green">&nbsp<?php

								$Today = date('m:d:y');
								$new = date('l, F d, Y', strtotime($Today));
								echo $new;
								?>
								</p></div>
								</body>
								</html>

								