<script type="text/javascript">
function printTable("cert.php") 
{
    var w = window.open(Table);
    w.print();
}
</script>