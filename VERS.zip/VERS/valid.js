function validate(){
var child=document.b1.name;
if(child.value===""){
child.style.visibility="visible";
}
}