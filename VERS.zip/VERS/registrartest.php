<html>
<div id="container">
<div id="header">
<head>


<?php 
session_start();
if(!$_SESSION['loggedin'])
{
header("location:login2.php");
exit;
}
else
echo"<p align='right'><h3><font color='orange'>Welcome Registrar $username</h4></font></p>";
?>
<link a href="profile.css" type="text/css" rel="stylesheet"></div>
<div id="sidebar">
<a href="staffmessage.php" onclick="view">Messages</a><hr>
<a href="tasks.php" onclick="view">Tasks</a><br>
<hr><a href="myagents.php" onclick="view">My Agents</a><br><hr>
<a href="approve.php" onclick="view">Approve Registers</a><br><hr>
<ul><a href="#" onclick="view">View Registers</a><ul><li><a href="viewb.php">Birth</a><br><li><a href="viewd.php">Death</a><br></ul><hr>
<a href="cert.php" onclick="view">Process Certificates</a><br><hr>
<a href="stat1.php" onclick="view">Statistics</a><br><hr>
<a href="logoff.php" onclick="view">Log out</a><hr></td>
</div>
<div id="mainBody">

</div>
<div id="footer">

<?php include("footer.php");?></div></div>
<script type="text/javascript">
function view(){
document.getElementById("mainBody");
}
</script>
</body>
</html>