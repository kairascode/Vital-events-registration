<?php include("header.php");?>
<a href="profile3.php">BACK</a>
<HTML>
<?php
$db = mysql_connect("localhost","root", "");
mysql_select_db("pomis",$db);
$result = mysql_query("SELECT * FROM agents");
echo "<TABLE BORDER=2>";

echo"<TR><TD><B>USERNAME</B><TD><B>USER CODE</B><TD><B>PASSWORD</B></TR>";
while ($myrow = mysql_fetch_array($result))
{
echo "<TR><TD>".$myrow["username"]."<td>".$myrow["usercode"]." <td>".$myrow["password"];

}
echo "</TABLE>";
?>

</HTML>
<?php include("footer.php");?>