<link rel="stylesheet" type="text/css" a href="pmis.css" media="all">
<div id="foot">
<p align="center">ALL RIGHTS RESERVED &copy<?php $Today = date('m:d:y'); $new = date('Y', strtotime($Today));
								echo $new;?> <br>
<p align="center">THE VERS SYSTEM HAS BEEN DESIGNED AND DEVELOPED BY ALEX KAIRA</p>
</div>

								